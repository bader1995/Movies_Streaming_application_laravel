# Chill4Free Movies streaming web application made with laravel 5.8 by Bader El Hayah

# This application is easy and smooth with maximum security, you can use it to post videos or movies

# It also contains user management which allows a user to comment for a video or a movie

# You can make it better by adding some new styles etc ...