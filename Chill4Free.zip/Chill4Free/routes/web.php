<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'moviesController@all_movies');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/movies', 'moviesController@index')->name('movies');

Route::get('/contact-us', 'HomeController@index')->name('contact-us');

Route::get('/about-us', 'HomeController@index')->name('about-us');

Route::get('/category/{id}', 'moviesController@movies_by_category')->name('movies_by_category');

Route::get('/movies/view/{id}', 'moviesController@movie_by_id')->name('view_movie')->middleware('auth');

Route::get('/admin', 'adminController@index')->middleware('auth')->middleware('checkAdmin');

Route::post('/admin/panel', 'moviesController@add_movie');

Route::delete('/admin/panel', 'moviesController@delete_movie');

Route::post('/movies/view', 'commentsController@add_comment')->middleware('auth');