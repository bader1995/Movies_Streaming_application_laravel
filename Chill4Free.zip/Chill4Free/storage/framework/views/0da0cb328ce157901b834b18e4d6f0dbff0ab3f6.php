<?php $__env->startSection('content'); ?>

	<h2>Movies List</h2>

	<div class="row">
		<div class="col-md-4">
			<div class="card">
				div.card-header
			</div>
		</div>
		<div class="col-md-4">
			
		</div>
		<div class="col-md-4">
			
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\movies4free\resources\views/category.blade.php ENDPATH**/ ?>