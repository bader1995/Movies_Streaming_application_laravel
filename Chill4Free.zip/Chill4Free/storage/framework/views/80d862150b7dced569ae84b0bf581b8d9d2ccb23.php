<?php $__env->startSection('content'); ?>

    <!-- Start ads -->
    <div class="row mt-3 mb-3">
        <div class="container">
            <!-- ads code here -->
        </div>
    </div>
    <!-- End ads -->

    <!-- Movie name -->
    <div class="row text-center mt-3 mb-3">
        <div class="col-md-12">
            <h2 class="text-white"><?php echo e($movie->name); ?></h2>
        </div>
    </div>
    <!-- End Movie name -->

    <!-- Start Content -->
    <div class="row">
        <div class="col-md-12">
            <div class="container">
                <video controls="controls" class="container-fluid" src="<?php echo e(asset( $movie->stream_url )); ?>"></video>
            </div>
        </div>
    </div>
    <!-- End Content -->

    <!-- Start buttons -->
    <div class="row mt-3 mb-3">
        <div class="col-md-12 text-center">
            <div class="container">
                <a href="<?php echo e(asset( $movie->stream_url )); ?>" class="btn btn-lg btn-primary">Download Now</a>
            </div>
        </div>
    </div>
    <!-- End buttons -->

    <!-- Start ads -->
    <div class="row mt-3 mb-3">
        <div class="container">
            <!-- ads code here -->
        </div>
    </div>
    <!-- End ads -->

    <!-- Recommanded movies start -->
    <div class="container mt-5 mb-5 text-center">
        <h4 class="mt-5 mb-5 text-white">Recommanded movies</h4>
        <div class="row">
            <?php $__currentLoopData = $recommanded_movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header text-center">
                            <?php echo e($movie1->name); ?>

                        </div>
                        <div class="card-body text-center">
                            <img src="<?php echo e(asset( 'storage/'.$movie1->image )); ?>" alt="<?php echo e($movie1->name); ?>">
                        </div>
                        <div class="card-footer text-center">
                            <a class="btn btn-success text-white mb-2" href="<?php echo e(asset('movies/view/'.$movie1->id)); ?>">Watch Now</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- Recommanded movies end -->

    <!-- Start ads -->
    <div class="row mt-3 mb-3">
        <div class="container">
            <!-- ads code here -->
        </div>
    </div>
    <!-- End ads -->

    <!-- Start comments -->
    <div class="row mt-3 mb-3">
        <div class="col-md-12">
            <div class="container">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row mt-3 mb-3">
        <div class="col-md-12">
            <!-- Start add comment -->
                <div class="container mb-5">
                    <form action="<?php echo e(url('/movies/view')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <textarea name="content" class="form-control"></textarea>
                        </div>
                        <input type="hidden" name="user" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                        <input type="hidden" name="movie" value="<?php echo e($movie->id); ?>">
                        <div class="form-group">
                            <input type="submit" class="form-control btn btn-primary" value="Comment">
                        </div>
                    </form>
                </div>
            <!-- End add comment -->

            <!-- Start show comments -->
                <div class="container">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mt-2 mb-2">
                            <div class="card-header bg-dark text-white font-weight-bold">
                                Username : <?php echo e($comment->username); ?>

                            </div>
                            <div class="card-body bg-dark text-white">
                                <?php echo e($comment->content); ?>

                            </div>
                            <div class="card-footer bg-dark text-white text-right">
                                <?php echo e($comment->created_at); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <!-- End show comments -->
        </div>
    </div>
    <!-- End comments -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\movies4free\resources\views/view.blade.php ENDPATH**/ ?>