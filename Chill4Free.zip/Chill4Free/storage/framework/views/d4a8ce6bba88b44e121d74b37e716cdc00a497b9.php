<?php $__env->startSection('content'); ?>

    <div class="row">

        <!-- Start Add new movie -->
        <div class="col-md-6">
            <div class="container">
                <?php if($errors->any()): ?>)
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php echo e($error); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form action="<?php echo e(url('admin/panel')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <h3 class="mt-5 mb-5 text-white text-center">Add new movie</h3>
                    <div class="form-group">
                        <input type="text" class="form-control" name="name" placeholder="Movie name" value="<?php echo e(old('name')); ?>"/>
                    </div>
                    <div class="form-group">
                        <select name="language" class="form-control">
                            <option value="english">English</option>
                            <option value="french">French</option>
                            <option value="arabic">Arabic</option>
                            <option value="sweedich">Sweedich</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="rank" placeholder="Movie rank" value="<?php echo e(old('rank')); ?>"/>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="description" placeholder="Movie description ..." value="<?php echo e(old('description')); ?>"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="text" name="stream_url" class="form-control" placeholder="Stream URL" value="<?php echo e(old('stream_url')); ?>" >
                    </div>
                    <div class="form-group">
                        <select name="category" class="form-control">
                            <option value="1">Action</option>
                            <option value="2">Horror</option>
                            <option value="3">Adventure</option>
                            <option value="4">Anime</option>
                            <option value="5">Comedy</option>
                            <option value="6">Fantasy</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="file" class="form-control" name="image" value="<?php echo e(old('image')); ?>"/>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="save" value="Save" class="form-control btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
        <!-- End add new movie -->

        <!-- Start delete movie -->
        <div class="col-md-6">
            <div class="container">
                <h3 class="mt-5 mb-5 text-white text-center">Delete movie by name</h3>
                <form action="<?php echo e(url('admin/panel')); ?>" method="post">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <select name="id" class="form-control">
                            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($movie->id); ?>"><?php echo e($movie->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="delete" value="Delete" class="btn btn-danger form-control" />
                    </div>
                </form>
            </div>
        </div>
        <!-- End delete movie -->

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\movies4free\resources\views/auth/admin/panel.blade.php ENDPATH**/ ?>