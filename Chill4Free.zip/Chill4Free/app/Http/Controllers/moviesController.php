<?php

namespace App\Http\Controllers;

use App\Comment;
use App\User;
use Illuminate\Http\Request;
use App\Movie;
use Illuminate\Support\Facades\DB;

class moviesController extends Controller
{
    public function add_movie(Request $request)
    {
        $validatedData = $request->validate([
            "name" => "required|min:3|max:32",
            "language" => "required",
            "image" => "file|image|max:5000",
            "stream_url" => "required",
            "rank" => "required",
            "description" => "required|min:10|max:250",
            "category" => "required"
        ]);

        $movie = Movie::create($validatedData);

        $this->storeImage($movie);

        return redirect("/");
    }

    public function storeImage($movie)
    {
        if(request()->has('image'))
        {
            $movie->update([
                'image' => request()->image->store('uploads', 'public'),
            ]);
        }
    }

    public function delete_movie(Request $request)
    {
        $id = $request->id;

        Movie::where('id', $id)->delete();

        return redirect("admin/");
    }

    public function find_movies(Request $request)
    {
        $id = $request->id;

        $movie = Movie::find($id);

        return $movie;
    }

    public function all_movies()
    {
        $movies = Movie::all();
    	return view("welcome", ["movies" => $movies]);
    }

    public function movies_by_category(Request $request)
    {
        $category_id = $request->id;

        $movies = Movie::all()->where('category', $category_id);

        return view("/welcome", ["movies" => $movies]);
    }

    public function movie_by_id(Request $request)
    {
        // get the movie to watch
        $id = $request->id;

        $movie = new Movie();

        $movie = $movie->find($id);

        // get recommanded movies list to show at the banner
        $recommanded_movies = Movie::all()->where("id", ">", 0)->where("id", "<", 6);

        // get comments list
        $comments = DB::select("select comments.content, comments.created_at, users.username from comments inner join users on comments.user = users.id where comments.movie = " . $id);

        return view('view', ["movie" => $movie, "recommanded_movies" => $recommanded_movies, "comments" => $comments] );

    }

}
