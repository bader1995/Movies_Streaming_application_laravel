<?php

namespace App\Http\Controllers;

use App\Comment;
use Illuminate\Http\Request;

class commentsController extends Controller
{
    public function add_comment()
    {
        $validatedData = request()->validate([
            "content" => "required|min:5|max:200",
            "movie" => "required",
            "user" => "required"
        ]);

        Comment::create($validatedData);

        return redirect("movies/view/".$validatedData["movie"]);
    }
}
