<?php

namespace App\Http\Controllers;

use App\Movie;
use Illuminate\Http\Request;

class adminController extends Controller
{
    public function index()
    {
        $movies = Movie::all();

        return view("auth.admin.panel", ["movies" => $movies]);
    }
}
