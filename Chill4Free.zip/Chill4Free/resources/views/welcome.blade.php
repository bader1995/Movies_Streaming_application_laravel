@extends('layouts/app')

@section('content')

    <!-- Carousel start -->
    <div class="row">
        <div class="col-md-12">
            <div class="jumbotron text-center">
                <div id="demo" class="carousel slide" data-ride="carousel">

                    <!-- Indicators -->
                    <ul class="carousel-indicators">
                        <li data-target="#demo" data-slide-to="0" class="active"></li>
                        <li data-target="#demo" data-slide-to="1"></li>
                        <li data-target="#demo" data-slide-to="2"></li>
                    </ul>

                    <!-- The slideshow -->
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="{{ asset('img/banner.jpg') }}">
                        </div>
                        <div class="carousel-item">
                            <img src="{{ asset('img/banner2.jpg') }}">
                        </div>
                        <div class="carousel-item">
                            <img src="{{ asset('img/banner3.png') }}">
                        </div>
                    </div>

                    <!-- Left and right controls -->
                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#demo" data-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </a>

                </div>
            </div>
        </div>
    </div>
    <!-- Carousel End -->

    <!-- Ads start -->
    <div class="row">
        <div class="col-md-12">
            <div class="container">
                <!-- Ads code here -->
            </div>
        </div>
    </div>
    <!-- Ads end -->

    <!-- Movies start -->
    <div class="row">
        @foreach($movies as $movie)
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-header text-center">
                        <b class="text-dark">{{ $movie->name }}</b>
                    </div>
                    <div class="card-body text-center">
                        <img class="img-thumbnail" src="{{ asset( 'storage/' . $movie->image ) }}" alt="{{ $movie->name }}">
                        <p>
                            <span class="text-hide">{{ $unchecked = 10 - $movie->rank }}</span>

                            @for($i=0;$i<$movie->rank;$i++)
                                <span class="fa fa-star checked"></span>
                            @endfor

                            @for($i=0;$i<$unchecked;$i++)
                                <span class="fa fa-star unchecked"></span>
                            @endfor
                        </p>
                    </div>
                    <div class="card-footer text-center">
                        <a class="btn btn-success text-white" href="{{ url('movies/view/' . $movie->id) }}">Watch Now</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
    <!-- Movies end -->

    <!-- Ads start -->
    <div class="row">
        <div class="col-md-12">
            <div class="container">
                <!-- Ads code here -->
            </div>
        </div>
    </div>
    <!-- Ads end -->

    <!-- Ads start -->
    <div class="row">
        <div class="col-md-12">
            <div class="container">
                <!-- Ads code here -->
            </div>
        </div>
    </div>
    <!-- Ads end -->

@endsection